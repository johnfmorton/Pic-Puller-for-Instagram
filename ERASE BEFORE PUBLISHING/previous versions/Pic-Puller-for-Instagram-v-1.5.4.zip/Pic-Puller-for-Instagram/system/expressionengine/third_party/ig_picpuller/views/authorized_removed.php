<h3>Authorization Removed</h3>

<p>You have removed this user's credentials from Expression Engine for <?=$moduleTitle;?>.</p>

<p>This does not revoke the Pic Puller application the Instagram user's account. To do that, you will need to visit the <a href="https://instagram.com/accounts/manage_access" target='instagram'>Instagram application management page</a>.</p>
