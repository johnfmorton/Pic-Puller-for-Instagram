<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Do I have cURL?</title>
</head>
<body>
	<?php
	// ### Checks for presence of the cURL extension.
	function _iscurlinstalled() {
		if  (in_array  ('curl', get_loaded_extensions())) {
			return true;
		}
		else{
			return false;
		}
	}
	if (_iscurlinstalled()) echo "cURL is installed"; else echo "cURL is NOT installed";	
	?>
</body>
</html>