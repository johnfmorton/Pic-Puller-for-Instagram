<h3>Instagram Authorization Successful for <em><?=$site_label;?></em>.</h3>
<p>You've authorized <?=$moduleShortTitle;?> to access your Instagram photos for use on <em><?=$site_label;?></em>.</p>
<p>You can remove this user's authorization anytime using the button below. You can re-authorize anytime you'd like.</p>
<br>
<p><a href="<?=$delete_method;?>" class='submit'>Remove Authorization for this user.</a></p>