<h3><?=$ig_advanced_menu;?> for <em><?=$site_label;?></em></h3>

<p>Select an advanced option below.</p>

<ul>
	<li><a href="<?=$adv_user_url;?>" class="submit"><?=$ig_adv_user_auth;?></a></li>

<!-- 
	<li><a href="#">Update the authorization URL.</a></li>
	<li><a href="#">tbd</a></li>
	<li><a href="#">tbd</a></li>
	<li><a href="#">tbd</a></li>

-->
</ul>
